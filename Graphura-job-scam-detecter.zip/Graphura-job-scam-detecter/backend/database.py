from backend.db.supabase import get_supabase_client

__all__ = ["get_supabase_client"]
