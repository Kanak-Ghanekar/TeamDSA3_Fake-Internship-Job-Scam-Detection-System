// Common chart defaults
Chart.defaults.font.family = "'Segoe UI', Arial, sans-serif";
Chart.defaults.color = '#6b7280';

// ── 1. TOP 15 COMPANIES (Horizontal Bar) ────────────────────────────────────
const companiesCtx = document.getElementById('companiesChart').getContext('2d');
new Chart(companiesCtx, {
  type: 'bar',
  data: {
    labels: ['Amazon','Accenture','Wipro','Google','Capgemini','Tcs','Miratech','Businessxdata'],
    datasets: [{
      label: 'Postings',
      data: [684, 512, 421, 374, 351, 349, 346, 341, 330, 325, 300, 203, 177, 169, 127],
      backgroundColor: '#a5b4fc',
      borderRadius: 4,
    }]
  },
  options: {
    indexAxis: 'y',
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false },
      datalabels: { display: false } },
    scales: {
      x: { grid: { color: '#f0f0f0' }, ticks: { stepSize: 100 } },
      y: { grid: { display: false } }
    }
  }
});

// ── 2. DONUT CHART – Source Domain ─────────────────────────────────────────
const donutCtx = document.getElementById('donutChart').getContext('2d');
new Chart(donutCtx, {
  type: 'doughnut',
  data: {
    labels: [
      'in.linkedin.com','in.indeed.com','Other','adzuna.in',
      'accenture.com','amazon.com','capgemini.com','deloitte.com','google.com','ibm.com'
    ],
    datasets: [{
      data: [36.55, 24.65, 17.51, 11.93, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56],
      backgroundColor: [
        '#a5b4fc','#86efac','#fde68a','#f9a8d4',
        '#c4b5fd','#fdba74','#6ee7b7','#fca5a5','#93c5fd','#5eead4'
      ],
      borderWidth: 2,
      borderColor: '#fff'
    }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    cutout: '55%',
    plugins: {
      legend: {
        display: true,
        position: 'left',
        labels: { boxWidth: 12, font: { size: 11 }, padding: 8 }
      },
      tooltip: {
        callbacks: {
          label: ctx => ` ${ctx.label}: ${ctx.parsed}%`
        }
      }
    }
  }
});

// ── 3. SCAM ROLE CHART (Grouped Bar) ───────────────────────────────────────
const scamRoleCtx = document.getElementById('scamRoleChart').getContext('2d');
new Chart(scamRoleCtx, {
  type: 'bar',
  data: {
    labels: [
      'AssociateProductM…','TalentAcquisitionS…','JavaDeveloper',
      'ProductDesigner','OperationsManager','FinanceExecutive',
      'KeyAccountManager','FrontendDeveloper','BackendDeveloper','CustomerSuccessM…'
    ],
    datasets: [
      {
        label: 'Avg Scam Score',
        data: [0.76, 0.75, 0.75, 0.74, 0.74, 0.73, 0.73, 0.72, 0.72, 0.72],
        backgroundColor: '#a5b4fc',
        yAxisID: 'y',
        borderRadius: 3,
      },
      {
        label: 'Postings Count',
        data: [33, 39, 63, 38, 37, 33, 28, 86, 63, 68],
        backgroundColor: '#86efac',
        yAxisID: 'y1',
        borderRadius: 3,
      }
    ]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      x: { grid: { display: false }, ticks: { maxRotation: 45, font: { size: 10 } } },
      y: {
        type: 'linear', position: 'left',
        grid: { color: '#f0f0f0' },
        ticks: { stepSize: 20 }
      },
      y1: {
        type: 'linear', position: 'right',
        grid: { drawOnChartArea: false },
        ticks: { stepSize: 20 }
      }
    }
  }
});

// ── 4. POSTING VOLUME OVER TIME (Line) ─────────────────────────────────────
const timeCtx = document.getElementById('timeChart').getContext('2d');
new Chart(timeCtx, {
  type: 'line',
  data: {
    labels: [
      'Sep 23, 2019','Jan 13, 2025','Feb 3, 2025','Feb 24, 2025','Mar 17, 2025',
      'Apr 7, 2025','Apr 28, 2025','May 19, 2025','Jun 9, 2025','Jun 30, 2025',
      'Jul 21, 2025','Aug 11, 2025','Sep 1, 2025','Sep 22, 2025','Oct 13, 2025',
      'Nov 3, 2025','Nov 24, 2025','Dec 15, 2025','Jan 5, 2026','Jan 26, 2026',
      'Feb 16, 2026','Mar 9, 2026','Mar 30, 2026','Apr 20, 2026','May 11, 2026',
      'Jun 1, 2026','Jun 8, 2026'
    ],
    datasets: [{
      label: 'Count',
      data: [
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,30,
        19,378,34,47,1249,5336,1183
      ],
      backgroundColor: 'rgba(165,180,252,0.25)',
      borderColor: '#818cf8',
      borderWidth: 2,
      fill: true,
      tension: 0.3,
      pointRadius: 3,
      pointBackgroundColor: '#818cf8'
    }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      x: { grid: { display: false }, ticks: { maxRotation: 45, font: { size: 9 }, maxTicksLimit: 10 } },
      y: { grid: { color: '#f0f0f0' }, ticks: { stepSize: 1000 } }
    }
  }
});

// ── 5. TOP 15 LOCATIONS (Bar) ───────────────────────────────────────────────
const locationCtx = document.getElementById('locationChart').getContext('2d');
new Chart(locationCtx, {
  type: 'bar',
  data: {
    labels: [
      'Hyderabad, Telangana','Bengaluru, Karnataka','Dl, In','Mh, In',
      'Ka, In','India','Remote','Bengaluru','Hyderabad','Delhi',
      'Mumbai','Chennai','Pune','Punedivision, Mah…','Mumbaimetro…'
    ],
    datasets: [
      { label: 'Hyderabad Telangana', data: [2244,0,0,0,0,0,0,0,0,0,0,0,0,0,0], backgroundColor: '#a5b4fc', borderRadius: 3 },
      { label: 'Bengaluru Karnataka', data: [0,1034,0,0,0,0,0,0,0,0,0,0,0,0,0], backgroundColor: '#86efac', borderRadius: 3 },
      { label: 'Dl In',               data: [0,0,847,0,0,0,0,0,0,0,0,0,0,0,0], backgroundColor: '#fde68a', borderRadius: 3 },
      { label: 'Mh In',               data: [0,0,0,650,0,0,0,0,0,0,0,0,0,0,0], backgroundColor: '#fca5a5', borderRadius: 3 },
      { label: 'Others',              data: [0,0,0,0,489,455,428,428,428,428,428,428,428,428,428], backgroundColor: '#c4b5fd', borderRadius: 3 }
    ]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: true, position: 'top', labels: { boxWidth: 12, font: { size: 10 } } }
    },
    scales: {
      x: { stacked: true, grid: { display: false }, ticks: { maxRotation: 45, font: { size: 9 } } },
      y: { stacked: true, grid: { color: '#f0f0f0' } }
    }
  }
});

// ── 6. SALARY DISTRIBUTION (Stacked Bar) ───────────────────────────────────
const salaryCtx = document.getElementById('salaryChart').getContext('2d');
new Chart(salaryCtx, {
  type: 'bar',
  data: {
    labels: ['0','1–10k','10k–50k','50k–100k','100k–1M','>1M'],
    datasets: [
      { label: 'in.linkedin.com', data: [6285, 50, 30, 20, 200, 80],  backgroundColor: '#a5b4fc', borderRadius: 3 },
      { label: 'adzuna.in',       data: [1758, 10, 5,  5,  50,  200], backgroundColor: '#86efac', borderRadius: 3 },
      { label: 'microsoft.com',   data: [100,  5,  5,  5,  30,  10],  backgroundColor: '#fde68a', borderRadius: 3 },
      { label: 'Other',           data: [142,  5,  5,  5,  2700,20],  backgroundColor: '#fca5a5', borderRadius: 3 }
    ]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      x: { stacked: true, grid: { display: false } },
      y: { stacked: true, grid: { color: '#f0f0f0' },
           ticks: { callback: v => v >= 1000 ? (v/1000)+'K' : v } }
    }
  }
});
